
public class Contact {
	private String contactID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	//sets Contact as a whole
	public Contact(String contactID, String fName, String lName, String phone, String address) {
		//sets contact ID
		if (contactID != null && contactID.length() <= 10) {
			this.contactID = contactID;
		}
		else{
	        throw new IllegalArgumentException("invalid input");
	      }
		this.setFirstName(fName);
		this.setLastName(lName);
		this.setPhoneNumber(phone);
		this.setAddress(address);
		
	}
	//sets first name
	public void setFirstName(String fName) {
		if (fName != null && fName.length() <= 10 ) {
			this.firstName = fName;
		}
		else{
	        throw new IllegalArgumentException("invalid input");
	      }
	}
	//sets last name
	public void setLastName(String lName) {
		if (lName != null && lName.length() <= 10 ) {
			this.lastName = lName;
		}
		else{
	        throw new IllegalArgumentException("invalid input");
	      }
	}
	
	//sets Phone number
	public void setPhoneNumber(String phone) {
		if(phone != null && phone.length() == 10) {
			this.phoneNumber = phone;
		}
		else{
	        throw new IllegalArgumentException("invalid input");
	      }
	}
	//sets address
	public void setAddress(String address) {
		if(address != null && address.length() <= 30) {
			this.address = address;
		}
		else{
	        throw new IllegalArgumentException("invalid input");
	      }
	}
	//gets Contact ID
	public String getContactID() {
		return contactID;
	}
	//gets first Name
	public String getFirstName() {
		return firstName;
	}
	//gets last Name
	public String getLastName() {
		return lastName;
	}
	//gets Phone Number
	public String getPhoneNumber() {
		return phoneNumber;
	}
	//gets address
	public String getAddress() {
		return address;
	}
	
	@Override
	public String toString() {
		return "Contact [contactID = " + contactID +", firstName = " + firstName + ", lastName = " + lastName + ", phoneNumber = " + phoneNumber + ", address = " + address + "]"; 
	}
}
