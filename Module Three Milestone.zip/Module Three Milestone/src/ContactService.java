import java.util.ArrayList;

public class ContactService {
	ArrayList<Contact> contacts;
	
	//establishing Array for contacts in contact list
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	//Adding contacts based on unique ID
	public boolean addContact(Contact newContact) {
		boolean contains = false;
		for (Contact c: contacts) {
			if (c.getContactID().equalsIgnoreCase(newContact.getContactID())) {
				contains = true;
				break;
			}
		}
		if (!contains) {
			contacts.add(newContact);
			System.out.println("Contact successfully added!");
			return true;
		}
		else {
			System.out.println("Contact already exists.");
			return false;
		}
	}
	
	//Deleting contacts based on unique ID
	public boolean deleteContact(String contactID) {
		boolean deleted = false;
		for (Contact c : contacts) {
			if (c.getContactID().equalsIgnoreCase(contactID)) {
				contacts.remove(c);
				deleted = true;
				System.out.println("Contact successfully deleted!");
				return true;
			}
		}
		System.out.println("Contact not found.");
		return deleted;
	}
	
	//updating first names for a contact ID
	public boolean updateContactFirstName(String contactID, String newFirstName) {
		boolean updated = false;
		for (Contact c : contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setFirstName(newFirstName);
				updated = true;
				System.out.println("Contact first name successfully updated!");
				break;
			}
		}
		System.out.println("Contact not found.");
		return updated;
	}
	
	//updating last names for a contact ID
	public boolean updateContactLastName(String contactID, String newLastName) {
		boolean updated = false;
		for (Contact c : contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setLastName(newLastName);
				updated = true;
				System.out.println("Contact last name successfully updated!");
				break;
			}
		}
		System.out.println("Contact not found.");
		return updated;
	}
	
	//updating Phone Number for a contact ID
	public boolean updateContactPhoneNumber(String contactID, String newPhoneNumber) {
		boolean updated = false;
		for (Contact c : contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setPhoneNumber(newPhoneNumber);
				updated = true;
				System.out.println("Contact phone number successfully updated!");
				break;
			}
		}
		System.out.println("Contact not found.");
		return updated;
	}
	
	//updating address for a contact ID
	public boolean updateContactAddress(String contactID, String newAddress) {
		boolean updated = false;
		for (Contact c : contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setAddress(newAddress);
				updated = true;
				System.out.println("Contact address successfully updated!");
				break;
			}
		}
		System.out.println("Contact not found.");
		return updated;
	}
	
}
