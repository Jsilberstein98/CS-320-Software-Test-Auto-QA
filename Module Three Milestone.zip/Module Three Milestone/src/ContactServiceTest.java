import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class ContactServiceTest {
	//Testing the add contacts method with details that are correct.
	@Test
	void testAddRightContact() {
		ContactService cs = new ContactService();
		Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
		Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
		Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
		assertEquals(true, cs.addContact(a));
		assertEquals(true, cs.addContact(b));
		assertEquals(true, cs.addContact(c));
	}
	//Testing the add contacts method with details that are already existing.
	@Test
	void testAddWrongContact() {
		ContactService cs = new ContactService();
		Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
		Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
		Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
		assertEquals(true, cs.addContact(a));
		//record already exists, so it cannot create a new contact.
		assertEquals(false, cs.addContact(a));
		assertEquals(true, cs.addContact(b));
		assertEquals(true, cs.addContact(c));
	}
	//Testing the delete contacts method with details that are correct for pass.
		@Test
		void testDeleteRightContact() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for a and b exist so they can be removed. 
			assertEquals(true, cs.deleteContact("1234567891"));
			assertEquals(true, cs.deleteContact("1234567892"));
		}
		//Testing the delete contacts method with details that are nonexistent for failure.
		@Test
		void testDeleteWrongContact() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for the new entry do not exist so they cannot be removed. 
			assertEquals(false, cs.deleteContact("1234567895"));
			assertEquals(true, cs.deleteContact("1234567892"));
		}
		
		//Testing the updating first names of contacts for passing.
		@Test
		void testUpdateFirstNameContactPass() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for the new entry exist so they can be updated. 
			assertEquals(true, cs.updateContactFirstName("1234567891", "george"));
			assertEquals(true, cs.updateContactFirstName("1234567892", "Brucey"));
		}
		
		//Testing the updating first names of contacts for failing.
		@Test
		void testUpdateFirstNameContactFail() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for the new entry do not exist so they cannot be updated. 
			assertEquals(false, cs.updateContactFirstName("1234567896", "george"));
			assertEquals(true, cs.updateContactFirstName("1234567892", "Brucey"));
		}
		//Testing the updating last names of contacts for passing.
		@Test
		void testUpdateLastNameContactPass() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for the new entry exist so they can be updated. 
			assertEquals(true, cs.updateContactLastName("1234567891", "Rogers"));
			assertEquals(true, cs.updateContactLastName("1234567892", "Banner"));
		}
		
		//Testing the updating last names of contacts for failing.
		@Test
		void testUpdateLastNameContactFail() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for the new entry do not exist so they cannot be updated. 
			assertEquals(false, cs.updateContactLastName("1234567896", "Rogers"));
			assertEquals(true, cs.updateContactLastName("1234567892", "Banner"));
		}
		//Testing the updating phone numbers of contacts for passing.
		@Test
		void testUpdatePhoneNumberContactPass() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// phone numbers for the new entry exist so they can be updated. 
			assertEquals(true, cs.updateContactPhoneNumber("1234567891", "9544288964"));
			assertEquals(true, cs.updateContactPhoneNumber("1234567892", "8008675309"));
		}
		
		//Testing the updating phone numbers of contacts for failing.
		@Test
		void testUpdatePhoneNumberContactFail() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for the new entry do not exist so they cannot be updated. 
			assertEquals(false, cs.updateContactPhoneNumber("1234567896", "9134567480"));
			assertEquals(true, cs.updateContactPhoneNumber("1234567892", "8008675309"));
		}
		
		//Testing the updating address of contacts for passing.
		@Test
		void testUpdatAddressContactPass() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			//addresses for the new entry exist so they can be updated. 
			assertEquals(true, cs.updateContactAddress("1234567891", "124 TOTALLY real address plaza"));
			assertEquals(true, cs.updateContactAddress("1234567892", "123 Not real address plaza"));
		}
		
		//Testing the updating Address of contacts for failing.
		@Test
		void testUpdateAddressContactFail() {
			ContactService cs = new ContactService();
			Contact a = new Contact("1234567891", "Selena", "Kyle", "9134458671", "124 real address plaza");
			Contact b = new Contact("1234567892", "bruce", "Wayne", "9134458672", "123 real address plaza");
			Contact c = new Contact("1234567893", "Edward", "Nigma", "9134458673", "122 real address plaza");
			assertEquals(true, cs.addContact(a));
			assertEquals(true, cs.addContact(b));
			assertEquals(true, cs.addContact(c));
			// ID's for the new entry do not exist so they cannot be updated. 
			assertEquals(false, cs.updateContactAddress("1234567896", "124 real address plaza"));
			assertEquals(true, cs.updateContactAddress("1234567892", "123 Not real address plaza"));
		}
}
