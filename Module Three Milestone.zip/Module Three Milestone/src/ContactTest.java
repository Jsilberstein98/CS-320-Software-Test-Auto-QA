import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	//test base conditions for true.
	@Test
	void testContact() {
		Contact contact = new Contact("1234567890", "John", "Wesley", "9134458670", "123 real address plaza");
		assertTrue(contact.getContactID().equals("1234567890"));
		assertTrue(contact.getFirstName().equals("John"));
		assertTrue(contact.getLastName().equals("Wesley"));
		assertTrue(contact.getPhoneNumber().equals("9134458670"));
		assertTrue(contact.getAddress().equals("123 real address plaza"));
		
	}
	//test contact ID for being too long
	@Test
	void testContactIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () ->{
			new Contact("12345678901", "John", "Wesley", "9134458670", "123 real address plaza");
		});
	}
	//test contact ID for being null
	@Test
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () ->{
			new Contact(null, "John", "Wesley", "9134458670", "123 real address plaza");
		});
    }
	//test First Name for being too long  
	@Test
	void testFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () ->{
			new Contact("1234567890", "Johnathaniel", "Wesley", "9134458670", "123 real address plaza");
		});
	}
	//test First Name for being null
	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () ->{
			new Contact("1234567890", null, "Wesley", "9134458670", "123 real address plaza");
		});
    }
	//test last Name for being too long
	@Test
	void testContactLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () ->{
			new Contact("1234567890", "John", "Westforshire", "9134458670", "123 real address plaza");
		});
    }
	//test last Name for being null
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,  () ->{
			new Contact("1234567890", "John", null, "9134458670", "123 real address plaza");
		});
	}
	//test Phone number for being too long
	@Test
    void testContactPhoneNumberToLong() {
      Assertions.assertThrows(IllegalArgumentException.class,  () ->{
        new Contact("1234567890", "John", "West", "91344586700", "123 real address plaza");
      });
    }
	//test Phone number for being null
    @Test
    void testContactPhoneNumberNull() {
      Assertions.assertThrows(IllegalArgumentException.class,  () ->{
        new Contact("1234567890", "John", "west", null, "123 real address plaza");
      });
    }
    //test address for being too long
    @Test
    void testContactAddressToLong() {
      Assertions.assertThrows(IllegalArgumentException.class,  () ->{
        new Contact("1234567890", "John", "West", "91344586700", "123 real address plaza, Tampa, Fl");
      });
    }
    //test address for being null
    @Test
    void testContactAddressNull() {
      Assertions.assertThrows(IllegalArgumentException.class,  () ->{
        new Contact("1234567890", "John", "west", "91344586700", null);
      });
    }
}
